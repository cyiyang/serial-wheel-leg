#ifndef __BSP_WDG_H__
#define __BSP_WDG_H__


void IWDG_Init(void);
void IWDG_Feed(void);

#endif
