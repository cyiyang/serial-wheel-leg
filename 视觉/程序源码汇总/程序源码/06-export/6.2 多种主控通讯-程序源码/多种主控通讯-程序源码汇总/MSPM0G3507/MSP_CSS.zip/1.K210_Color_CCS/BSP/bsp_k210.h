#ifndef __BSP_SERVO_H_
#define __BSP_SERVO_H_

#include "ti_msp_dl_config.h"
#include "k210_use.h"

void uart1_send_char(char ch);
void uart1_send_string(char* str);

#endif

