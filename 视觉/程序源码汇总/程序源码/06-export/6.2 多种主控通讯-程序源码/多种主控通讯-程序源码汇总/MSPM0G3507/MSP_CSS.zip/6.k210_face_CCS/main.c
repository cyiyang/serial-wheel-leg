#include "ti_msp_dl_config.h"
#include "bsp_delay.h"
#include "bsp_usart.h"
#include "stdio.h"
#include "bsp_k210.h"
#include "k210_use.h"


char buff_com[50];
msg_k210 k210_msg;//�յ�k210��Ϣ�ṹ��

//������
int main(void)
{
	SYSCFG_DL_init();

	NVIC_ClearPendingIRQ(MYUART_INST_INT_IRQN);//��������жϱ�־
	NVIC_EnableIRQ(MYUART_INST_INT_IRQN);//ʹ�ܴ����ж�

	

	while (1) 
	{    
		 if (k210_msg.class_n != 0)//���̺Ų�Ϊ��
		{
			if(k210_msg.class_n == 6)
			{				
				sprintf(buff_com,"x=%d,y=%d,w=%d,h=%d\r\n",k210_msg.x,k210_msg.y,k210_msg.w,k210_msg.h);
				uart0_send_string(buff_com);
				
				k210_msg.class_n = 0;	
			}
			
		}
		delay_ms(500);
		 
	}
} 



