#ifndef __LED_H
#define __LED_H

#include "AllHeader.h"


#define LED PCout(13)
void led_int(void);

#endif

